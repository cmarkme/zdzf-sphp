<?php 
$config['theme'] = 'default';

$config['site_name'] = "Alzheimer's Association";

$config['paginiation_segment'] = '3';

$config['pagination_per_page'] = 20;

$config['empty_message'] = 'Sorry there are no entries yet';

$config['gender'] = array('select' => 'Select', 'Male' => 'Male', 'Female' => 'Female');

$config['ethnicity'] = array('select' => 'Select', 'Caucasian' => 'Caucasian', 'Latino' => 'Latino', 'African American' => 'African American', 'API' => 'API', 'Other' => 'Other');

$config['relationship'] = array('select' => 'Select', 'Adult Child' => 'Adult Child', 'Spouse/Partner' => 'Spouse/Partner', 'Sibling' => 'Sibling', 'Grandchild' => 'Grandchild', 'Relative' => 'Relative', 'In-Law' => 'In-Law', 'Self' => 'Self', 'Friend' => 'Friend', 'Healthcare Provider' => 'Healthcare Provider', 'Other' => 'Other');

$config['education'] = array('select' => 'Select', 'High School' => 'High School', 'College' => 'College', 'Graduate Degree' => 'Graduate Degree', 'Other' => 'Other', 'Declined' => 'Declined');

$config['theme_style'] = site_url('themes/default/css/smoothness/jquery-ui-1.8.18.custom.css');