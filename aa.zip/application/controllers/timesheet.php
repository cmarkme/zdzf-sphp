<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Timesheet extends MY_Controller {
    
    function __construct()
	{
		parent::__construct();
        $this->load->helper('admin_helper');
	}

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -  
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in 
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	public function index()
	{  
		$offset = $this->uri->segment($this->config->item('paginiation_segment'));
		$list = $this->timesheet_model->get_timesheets(0, $this->config->item('pagination_per_page'), $offset, $this->input->get_post(NULL, TRUE));
		
		$p_config = array();
		$p_config['base_url'] = site_url('timesheet/page');
		$p_config['total_rows'] = $list['num_rows'];
		$p_config['uri_segment'] = $this->config->item('paginiation_segment');
		$p_config['per_page'] = $this->config->item('pagination_per_page');
		$p_config['num_links'] = 10;
		$p_config['full_tag_open'] = '<div class="pagination"><span>Pages:</span>';
		$p_config['full_tag_close'] = '</div>';
		$p_config['cur_tag_open'] = '<strong class="ui-state-hover ui-corner-all">';
		$p_config['cur_tag_close'] = '</strong>';
		$p_config['anchor_class'] = 'class="ui-state-default ui-corner-all"';
		$p_config['suffix'] = '?'.http_build_query($_GET, '', "&");
		$p_config['first_link'] = FALSE;
		$p_config['last_link'] = FALSE;

		$this->pagination->initialize($p_config);

       	$data['timesheets'] = $list['rows'];

		$this->load->view('timesheets/list', $data);
	}

	public function my_timesheets()
	{
		$offset = $this->uri->segment($this->config->item('paginiation_segment'));
		$list = $this->timesheet_model->get_timesheets($this->user->ID, $this->config->item('pagination_per_page'), $offset, $this->input->get_post(NULL, TRUE));
		
		$p_config = array();
		$p_config['base_url'] = site_url('timesheet/my_timesheets');
		$p_config['total_rows'] = $list['num_rows'];
		$p_config['uri_segment'] = $this->config->item('paginiation_segment');
		$p_config['per_page'] = $this->config->item('pagination_per_page');
		$p_config['num_links'] = 10;
		$p_config['full_tag_open'] = '<div class="pagination"><span>Pages:</span>';
		$p_config['full_tag_close'] = '</div>';
		$p_config['cur_tag_open'] = '<strong class="ui-state-hover ui-corner-all">';
		$p_config['cur_tag_close'] = '</strong>';
		$p_config['anchor_class'] = 'class="ui-state-default ui-corner-all"';
		$p_config['suffix'] = '?'.http_build_query($_GET, '', "&");
		$p_config['first_link'] = FALSE;
		$p_config['last_link'] = FALSE;

		$this->pagination->initialize($p_config);

       	$data['timesheets'] = $list['rows'];

		$this->load->view('timesheets/my_list', $data);
	}

	public function new_timesheet()
	{
		$load_view = 'timesheets/new';

		if($this->input->post('insert_timesheet')) 
		{
			$ts_id = $this->timesheet_model->save_timesheet($this->input->post(), $this->user->ID);

			$this->session->set_flashdata('timesheet', 'Timesheet Saved.');

			redirect('timesheet/my_timesheets');
		}

		if(NULL != $this->timesheet_model->get_template($this->user->ID))
		{
			$data['timesheet'] = $this->timesheet_model->get_template($this->user->ID);
			$data['grant_matching'] = array(
				'week1' => unserialize(base64_decode($data['timesheet']->gweek1)),
				'week2' => unserialize(base64_decode($data['timesheet']->gweek2))
			);

			$data['week1'] = unserialize(base64_decode($data['timesheet']->week1));
			$data['week2'] = unserialize(base64_decode($data['timesheet']->week2));
			$load_view = 'timesheets/new_from_template';
		}

		$data['accounts'] = $this->users_model->get_labor_accounts($this->user->ID, 'timesheet');
		$data['user'] = $this->user;
		$users = $this->users_model->get_all_users_meta();

		foreach($users as $user)
		{
			$data['users'][$user->ID] = $user->meta['first_name'].' '.$user->meta['last_name'];
		}
		asort($data['users']);

		$data['manager'] = $info = $this->users_model->get_user($data['user']->user_manager);

		$this->load->view($load_view, $data);
	}

	public function edit($id)
	{	
		if($this->input->post('update_timesheet')) {
			$this->timesheet_model->update_timesheet($this->input->post(), $this->uri->segment('3'), $this->input->post('user_id'));

			$this->session->set_flashdata('timesheet', 'Timesheet Updated.');
			redirect('timesheet/edit/'.$this->uri->segment('3'));
		}

		$data['timesheet'] = $this->timesheet_model->get_timesheet($id);

		$data['accounts'] = unserialize(base64_decode($data['timesheet']->accounts));
		if(!isset($data['accounts']) || !is_array($data['accounts'])) {
			$data['accounts'] = $this->users_model->get_labor_accounts($this->user->ID, 'timesheet');
		}

		$data['user'] = $this->users_model->get_user($data['timesheet']->user_id);
		$users = $this->users_model->get_all_users_meta();

		foreach($users as $user)
		{
			$data['users'][$user->ID] = $user->meta['first_name'].' '.$user->meta['last_name'];
		}
		asort($data['users']);

		$data['grant_matching'] = array(
			'week1' => unserialize(base64_decode($data['timesheet']->gweek1)),
			'week2' => unserialize(base64_decode($data['timesheet']->gweek2))
		);

		$data['week1'] = unserialize(base64_decode($data['timesheet']->week1));
		$data['week2'] = unserialize(base64_decode($data['timesheet']->week2));

		$data['manager'] = $info = $this->users_model->get_user($data['timesheet']->manager);

		$this->load->view('timesheets/edit', $data);
	}

	public function template_list()
	{
		$offset = $this->uri->segment($this->config->item('paginiation_segment'));
		$list = $this->timesheet_model->get_timesheets(0, $this->config->item('pagination_per_page'), $offset, $this->input->get_post(NULL, TRUE), 'template');
		
		$p_config = array();
		$p_config['base_url'] = site_url('timesheet');
		$p_config['total_rows'] = $list['num_rows'];
		$p_config['uri_segment'] = $this->config->item('paginiation_segment');
		$p_config['per_page'] = $this->config->item('pagination_per_page');
		$p_config['num_links'] = 10;
		$p_config['full_tag_open'] = '<div class="pagination"><span>Pages:</span>';
		$p_config['full_tag_close'] = '</div>';
		$p_config['cur_tag_open'] = '<strong class="ui-state-hover ui-corner-all">';
		$p_config['cur_tag_close'] = '</strong>';
		$p_config['anchor_class'] = 'class="ui-state-default ui-corner-all"';
		$p_config['suffix'] = '?'.http_build_query($_GET, '', "&");
		$p_config['first_link'] = FALSE;
		$p_config['last_link'] = FALSE;

		$this->pagination->initialize($p_config);

       	$data['timesheets'] = $list['rows'];

		$this->load->view('timesheets/template_list', $data);
	}

	public function new_template()
	{
		if($this->input->post('insert_template')) 
		{
			$ts_id = $this->timesheet_model->save_timesheet($this->input->post(), $this->input->post('user_id'), 'template');

			$this->session->set_flashdata('timesheet', 'Timesheet Template Saved');

			redirect('timesheet/edit_template/'.$ts_id);
		}

		$data['accounts'] = array_merge(array('' => 'Select Account'), $this->labor_model->get_account_list('timesheet'));

		$users = $this->users_model->get_all_users_meta();

		foreach($users as $user)
		{
			$data['users'][$user->ID] = $user->meta['first_name'].' '.$user->meta['last_name'];
		}
		asort($data['users']);

		$this->load->view('timesheets/template_new', $data);
	}

	public function edit_template($id)
	{	
		if($this->input->post('update_timesheet')) 
		{
			if($this->input->post('submit_request') == 'Create New Timesheet for the Current Pay Period from this Template')
			{
				$this->timesheet_model->save_timesheet($this->input->post(), $this->input->post('user_id'));
			}
			else
			{
				$this->timesheet_model->update_timesheet($this->input->post(), $id, $this->input->post('user_id'), 'template');
			}

			if ($this->input->post('submit_request') == 'Create New Timesheet for the Current Pay Period from this Template')
			{
				$this->session->set_flashdata('timesheet', 'New Timesheet Created.');
			}
			else
			{
				$this->session->set_flashdata('timesheet', 'Template Updated');
			}

			redirect('timesheet/edit_template/'.$id);
		}

		$data['accounts'] = array_merge(array('' => 'Select Account'), $this->labor_model->get_account_list('timesheet'));		

		$data['timesheet'] = $this->timesheet_model->get_timesheet($id);
		$data['user'] = $data['timesheet']->user_id;
		$data['grant_matching'] = array(
			'week1' => unserialize(base64_decode($data['timesheet']->gweek1)),
			'week2' => unserialize(base64_decode($data['timesheet']->gweek2))
		);

		$data['week1'] = unserialize(base64_decode($data['timesheet']->week1));
		$data['week2'] = unserialize(base64_decode($data['timesheet']->week2));

		$users = $this->users_model->get_all_users_meta();

		foreach($users as $user)
		{
			$data['users'][$user->ID] = $user->meta['first_name'].' '.$user->meta['last_name'];
		}
		asort($data['users']);

		$this->load->view('timesheets/template_edit', $data);
	}

	public function delete($id)
	{
		$this->db->where('id', $id)
		->delete('timesheets');

		redirect('timesheet');
	}

	public function delete_template($id)
	{
		$this->db->where('id', $id)
		->delete('timesheets');

		redirect('timesheet/template_list');
	}

	public function emails()
	{
		if($this->input->post('save_emails'))
		{
			$this->email_model->save_emails('timesheet', $this->input->post('email'));

			redirect('timesheet/emails');
		}

		$data = $this->email_model->get_emails('timesheet');
		$this->load->view('timesheets/emails', $data);
	}
}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */