<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Procurement extends MY_Controller {

	function __construct()
	{
		parent::__construct();
		set_title('Chapter Procurement');
	}

    public function index()
    {
        $data = array();

        $offset = $this->uri->segment($this->config->item('paginiation_segment'));
        $list = $this->procurement_model->get_orders(true, $this->config->item('pagination_per_page'), $offset, $this->input->get_post(NULL, TRUE));

        $p_config = array();
        $p_config['base_url'] = site_url('procurement/page');
        $p_config['total_rows'] = $list['num_rows'];
        $p_config['uri_segment'] = $this->config->item('paginiation_segment');
        $p_config['per_page'] = $this->config->item('pagination_per_page');
        $p_config['num_links'] = 10;
        $p_config['full_tag_open'] = '<div class="pagination"><span>Pages:</span>';
        $p_config['full_tag_close'] = '</div>';
        $p_config['cur_tag_open'] = '<strong class="ui-state-hover ui-corner-all">';
        $p_config['cur_tag_close'] = '</strong>';
        $p_config['anchor_class'] = 'class="ui-state-default ui-corner-all"';
        $p_config['suffix'] = '?'.http_build_query($_GET, '', "&");
        $p_config['first_link'] = FALSE;
        $p_config['last_link'] = FALSE;

        $this->pagination->initialize($p_config);

        $data['procurements'] = $list['rows'];

    	$this->load->view('procurement/list', $data);
    }

    public function all_orders()
    {
        $data = array();

        $offset = $this->uri->segment($this->config->item('paginiation_segment'));
        $list = $this->procurement_model->get_orders(false, $this->config->item('pagination_per_page'), $offset, $this->input->get_post(NULL, TRUE));

        $p_config = array();
        $p_config['base_url'] = site_url('procurement');
        $p_config['total_rows'] = $list['num_rows'];
        $p_config['uri_segment'] = $this->config->item('paginiation_segment');
        $p_config['per_page'] = $this->config->item('pagination_per_page');
        $p_config['num_links'] = 10;
        $p_config['full_tag_open'] = '<div class="pagination"><span>Pages:</span>';
        $p_config['full_tag_close'] = '</div>';
        $p_config['cur_tag_open'] = '<strong class="ui-state-hover ui-corner-all">';
        $p_config['cur_tag_close'] = '</strong>';
        $p_config['anchor_class'] = 'class="ui-state-default ui-corner-all"';
        $p_config['suffix'] = '?'.http_build_query($_GET, '', "&");
        $p_config['first_link'] = FALSE;
        $p_config['last_link'] = FALSE;

        $this->pagination->initialize($p_config);

        $data['procurements'] = $list['rows'];

        $this->load->view('procurement/all_orders', $data);
    }

    public function my_orders()
    {
        $data = array();

        $offset = $this->uri->segment($this->config->item('paginiation_segment'));
        $list = $this->procurement_model->get_orders($this->user->ID, $this->config->item('pagination_per_page'), $offset, $this->input->get_post(NULL, TRUE));

        $p_config = array();
        $p_config['base_url'] = site_url('procurement');
        $p_config['total_rows'] = $list['num_rows'];
        $p_config['uri_segment'] = $this->config->item('paginiation_segment');
        $p_config['per_page'] = $this->config->item('pagination_per_page');
        $p_config['num_links'] = 10;
        $p_config['full_tag_open'] = '<div class="pagination"><span>Pages:</span>';
        $p_config['full_tag_close'] = '</div>';
        $p_config['cur_tag_open'] = '<strong class="ui-state-hover ui-corner-all">';
        $p_config['cur_tag_close'] = '</strong>';
        $p_config['anchor_class'] = 'class="ui-state-default ui-corner-all"';
        $p_config['suffix'] = '?'.http_build_query($_GET, '', "&");
        $p_config['first_link'] = FALSE;
        $p_config['last_link'] = FALSE;

        $this->pagination->initialize($p_config);

        $data['procurements'] = $list['rows'];

        $this->load->view('procurement/all_orders', $data);
    }

    public function templates()
    {
        $data = array();

        $data['templates'] = $this->procurement_model->get_templates();

        $this->load->view('procurement/templates_list', $data);
    }

    public function new_template()
    {

        if($this->input->post('save_template'))
        {
            $t_id = $this->procurement_model->save_template($this->input->post());

            $this->session->set_flashdata('procurement', 'The template has been created.');

            redirect('procurement/edit/'.$t_id);
        }

        $this->load->view('procurement/new_template');
    }

    public function edit($id)
    {
        $data = array();

        $data['template'] = $this->procurement_model->get_template($id);

    	if($this->input->post('update_template'))
    	{
    		$this->procurement_model->edit_template($id, $this->input->post());

            $this->session->set_flashdata('procurement', 'The template has been updated.');

            redirect('procurement/edit/'.$id);
    	}

    	$this->load->view('procurement/edit_template', $data);
    }

    public function create($id, $product = false)
    {
        if($this->input->post('save_order'))
        {
            $order_id = $this->procurement_model->save_order($id, $this->input->post());

            $this->session->set_flashdata('procurement', 'The order has been saved.');

            redirect('procurement/order/'.$id.'/'.$order_id);
        }

        if($product) {

            $info = $this->procurement_model->get_product($id, $product);

            echo json_encode($info);
            die();
        }

        $data['template'] = $this->procurement_model->get_template($id);
        $data['products'][''] = 'Select Product';

        foreach($data['template']->products as $product)
        {
            $data['products'][$product->ID] = $product->item_name;
        }

        $data['user'] = $this->user;
        $data['accounts'] = $this->users_model->get_labor_accounts($this->user->ID, 'procurement');

        $this->load->view('procurement/create_template', $data);
    }

    public function order($id, $order, $product = false)
    {
        if($this->input->post('save_order'))
        {
            $order_id = $this->procurement_model->save_order($id, $this->input->post());

            $this->session->set_flashdata('procurement', 'The order has been saved.');

            redirect('procurement/order/'.$id.'/'.$order_id);
        }

        if($product) {

            $info = $this->procurement_model->get_product($id, $product);

            echo json_encode($info);
            die();
        }

        $data['template'] = $this->procurement_model->get_template($id);
        $data['order'] = $this->procurement_model->get_order($id, $order);
        $data['products'][''] = 'Select Product';

        foreach($data['template']->products as $product)
        {
            $data['products'][$product->ID] = $product->item_name;
        }

        $data['user'] = $this->user;
        $data['accounts'] = $this->users_model->get_labor_accounts($this->user->ID, 'procurement');

        $this->load->view('procurement/order_template', $data);
    }

    public function delete($template, $order = FALSE)
    {
        if($order == FALSE)
        {
            $this->session->set_flashdata('procurement', 'The template has been deleted.');
            
            $this->db->where('ID', $template)->delete('chapter_procurement_templates');
        }
        else
        {
            $this->session->set_flashdata('procurement', 'The order has been deleted.');

            $this->db->where(array('template_id' => $template, 'ID' => $order))->delete('chapter_procurement_orders');
            $this->db->where('order_id', $order)->delete('chapter_procurement_order_products');
        }

        redirect('procurement');
    }

}

/* End of file procurement.php */
/* Location: ./application/controllers/procurement.php */