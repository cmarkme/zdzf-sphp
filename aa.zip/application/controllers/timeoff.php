<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Timeoff extends MY_Controller {
    
    function __construct()
	{
		parent::__construct();
        $this->load->helper('admin_helper');
	}

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -  
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in 
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	public function index()
	{  
		$offset = $this->uri->segment($this->config->item('paginiation_segment'));
		$list = $this->timeoff_model->get_timeoff_requests(0, $this->config->item('pagination_per_page'), $offset, $this->input->get_post(NULL, TRUE));
		
		$p_config = array();
		$p_config['base_url'] = site_url('timeoff/page');
		$p_config['total_rows'] = $list['num_rows'];
		$p_config['uri_segment'] = $this->config->item('paginiation_segment');
		$p_config['per_page'] = $this->config->item('pagination_per_page');
		$p_config['num_links'] = 10;
		$p_config['full_tag_open'] = '<div class="pagination"><span>Pages:</span>';
		$p_config['full_tag_close'] = '</div>';
		$p_config['cur_tag_open'] = '<strong class="ui-state-hover ui-corner-all">';
		$p_config['cur_tag_close'] = '</strong>';
		$p_config['anchor_class'] = 'class="ui-state-default ui-corner-all"';
		$p_config['suffix'] = '?'.http_build_query($_GET, '', "&");
		$p_config['first_link'] = FALSE;
		$p_config['last_link'] = FALSE;

		$this->pagination->initialize($p_config);

       	$data['timeoff_requests'] = $list['rows'];

		$this->load->view('timeoff/requests', $data);
	}

	public function my_timeoff_requests()
	{	
		$offset = $this->uri->segment($this->config->item('paginiation_segment'));
		$list = $this->timeoff_model->get_timeoff_requests($this->user->ID, $this->config->item('pagination_per_page'), $offset, $this->input->get_post(NULL, TRUE));
		
		$p_config = array();
		$p_config['base_url'] = site_url('timeoff/my_timeoff_requests');
		$p_config['total_rows'] = $list['num_rows'];
		$p_config['uri_segment'] = $this->config->item('paginiation_segment');
		$p_config['per_page'] = $this->config->item('pagination_per_page');
		$p_config['num_links'] = 10;
		$p_config['full_tag_open'] = '<div class="pagination"><span>Pages:</span>';
		$p_config['full_tag_close'] = '</div>';
		$p_config['cur_tag_open'] = '<strong class="ui-state-hover ui-corner-all">';
		$p_config['cur_tag_close'] = '</strong>';
		$p_config['anchor_class'] = 'class="ui-state-default ui-corner-all"';
		$p_config['suffix'] = '?'.http_build_query($_GET, '', "&");
		$p_config['first_link'] = FALSE;
		$p_config['last_link'] = FALSE;

		$this->pagination->initialize($p_config);

       	$data['timeoff_requests'] = $list['rows'];

		$this->load->view('timeoff/my_requests', $data);
	}

	public function new_timeoff_request()
	{
		if($this->input->post('insert_timeoff_request')) 
		{
			$ts_id = $this->timeoff_model->save_timeoff_request($this->input->post(), $this->user->ID);

			$this->session->set_flashdata('timeoff', 'Your timeoff request has been saved.');

			redirect('timeoff/edit/'.$ts_id);
		}

		$data['user'] = $this->user;

		$this->load->view('timeoff/request_new', $data);
	}

	public function edit($id)
	{	
		if($this->input->post('update_timeoff_request')) {
			$this->timeoff_model->update_timeoff_request($this->input->post(), $this->uri->segment('3'));

			$this->session->set_flashdata('timeoff', 'Your eidts to the timeoff request have been saved.');

			redirect('timeoff/edit/'.$this->uri->segment('3'));
		}

		$data['timeoff_request'] = $this->timeoff_model->get_timeoff_request($id);
		$data['user'] = $this->users_model->get_user($data['timeoff_request']->user_id);

		$this->load->view('timeoff/request_edit', $data);
	}

	public function delete($id)
	{
		$this->db->where('id', $id)
		->delete('timeoff_requests');

		$this->session->set_flashdata('timeoff', 'The timeoff request has been deleted.');

		redirect('timeoff');
	}

	public function emails()
	{
		if($this->input->post('save_emails'))
		{
			$this->email_model->save_emails('timeoff', $this->input->post('email'));

			$this->session->set_flashdata('timeoff', 'Timeoff emails have been updated.');

			redirect('timeoff/emails');
		}

		$data = $this->email_model->get_emails('timeoff');
		$this->load->view('timeoff/emails', $data);
	}
}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */