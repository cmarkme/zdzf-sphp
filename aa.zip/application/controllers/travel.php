<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Travel extends MY_Controller {
    
    function __construct()
	{
		parent::__construct();
        $this->load->helper('admin_helper');
		set_title('Travel');
	}

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -  
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in 
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	public function index()
	{ 
		$offset = $this->uri->segment($this->config->item('paginiation_segment'));
		$list = $this->travel_model->get_travel_requests(0, $this->config->item('pagination_per_page'), $offset, $this->input->get_post(NULL, TRUE));
		
		$p_config = array();
		$p_config['base_url'] = site_url('travel/page');
		$p_config['total_rows'] = $list['num_rows'];
		$p_config['uri_segment'] = $this->config->item('paginiation_segment');
		$p_config['per_page'] = $this->config->item('pagination_per_page');
		$p_config['num_links'] = 10;
		$p_config['full_tag_open'] = '<div class="pagination"><span>Pages:</span>';
		$p_config['full_tag_close'] = '</div>';
		$p_config['cur_tag_open'] = '<strong class="ui-state-hover ui-corner-all">';
		$p_config['cur_tag_close'] = '</strong>';
		$p_config['anchor_class'] = 'class="ui-state-default ui-corner-all"';
		$p_config['suffix'] = '?'.http_build_query($_GET, '', "&");
		$p_config['first_link'] = FALSE;
		$p_config['last_link'] = FALSE;

       	$data['travel_requests'] = $list['rows'];

       	$this->pagination->initialize($p_config);

		$this->load->view('travel_requests/list', $data);
	}

	public function my_travel_requests()
	{
		$offset = $this->uri->segment($this->config->item('paginiation_segment'));
		$list = $this->travel_model->get_travel_requests($this->user->ID, $this->config->item('pagination_per_page'), $offset, $this->input->get_post(NULL, TRUE));
		
		$p_config = array();
		$p_config['base_url'] = site_url('travel/my_travel_requests');
		$p_config['total_rows'] = $list['num_rows'];
		$p_config['uri_segment'] = $this->config->item('paginiation_segment');
		$p_config['per_page'] = $this->config->item('pagination_per_page');
		$p_config['num_links'] = 10;
		$p_config['full_tag_open'] = '<div class="pagination"><span>Pages:</span>';
		$p_config['full_tag_close'] = '</div>';
		$p_config['cur_tag_open'] = '<strong class="ui-state-hover ui-corner-all">';
		$p_config['cur_tag_close'] = '</strong>';
		$p_config['anchor_class'] = 'class="ui-state-default ui-corner-all"';
		$p_config['suffix'] = '?'.http_build_query($_GET, '', "&");
		$p_config['first_link'] = FALSE;
		$p_config['last_link'] = FALSE;

       	$data['travel_requests'] = $list['rows'];

       	$this->pagination->initialize($p_config);

		$this->load->view('travel_requests/my_requests', $data);
	}

	public function new_travel_request()
	{
		if($this->input->post('insert_travel_request')) 
		{
			$ts_id = $this->travel_model->save_travel_request($this->input->post(), $this->user->ID);

			$this->session->set_flashdata('travel', 'The travel request has been saved.');
			redirect('travel/edit/'.$ts_id);
		}

		$data['user'] = $this->user;
		$data['users'] = $this->users_model->get_all_users_meta();
		$data['accounts'] = array_merge(array('' => 'Select Account'), $this->labor_model->get_account_list('travel'));
		$data['mileage_rate'] = get_option('mileage_rate', true);

		$this->load->view('travel_requests/new', $data);
	}

	public function edit($id)
	{	
		if($this->input->post('update_travel_request')) {
			$this->travel_model->update_travel_request($this->input->post(), $this->uri->segment('3'));

			$this->session->set_flashdata('travel', 'The travel request has been update.');
			redirect('travel/edit/'.$this->uri->segment('3'));
		}

		$data['travel_request'] = $this->travel_model->get_travel_request($id);
		$data['user'] = $this->users_model->get_user($data['travel_request']['details']->user_id);
		$data['accounts'] = array_merge(array('' => 'Select Account'), $this->labor_model->get_account_list('travel'));
		$data['users'] = $this->users_model->get_all_users_meta();

		$this->load->view('travel_requests/edit', $data);
	}

	public function delete($id)
	{
		if(can_this_user('travel/delete'))
		{
			$this->db->where('id', $id)
			->delete('travel_requests');

			$this->db->where('travel_id', $id)
			->delete('travel_request_details');

			$this->db->where('travel_id', $id)
			->delete('travel_out_of_town_details');

			$this->session->set_flashdata('travel', 'Travel request has been deleted.');
		}
		else
		{
			$this->session->set_flashdata('travel', 'You cannot delete this document');
		}

		redirect('travel');
	}

	public function emails()
	{
		if($this->input->post('save_emails'))
		{
			$this->email_model->save_emails('travel', $this->input->post('email'));

			redirect('travel/emails');
		}

		$data = $this->email_model->get_emails('travel');
		$this->load->view('travel_requests/emails', $data);
	}
}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */