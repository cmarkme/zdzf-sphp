<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Users extends MY_Controller {
    
    var $cap_list = array(
            array('name' => 'Admin',
            	'controller' => 'controller_admin',
                'subs' => array(
                    'admin/general' => 'General Settings',
                    'admin/account_codes' => 'Account Codes',
                    'admin/discretionary_accounts' => 'Discretionary Accounts',
                    'admin/locations' => 'Office Locations',
                    'admin/reference_agencies' => 'Reference Agencies',
                    'admin/user_settings' => 'User Settings',
                    'admin/lasrmetrics_settings' => 'LasrMetrics Settings',
                    'admin/calendar_settings' => 'Calendar Settings',
                    )
            ),array('name' => 'Users',
            	'controller' => 'controller_users',
                'subs' => array(
                    'users' => 'View User List',
                    'users/add' => 'Add User',
                    'users/edit' => 'Edit Users',
                    'users/delete' => 'Delete Users',
                    'users/manage_roles' => 'Manage Roles',
                    'users/add_role' => 'Add Roles',
                    'users/edit_role' => 'Edit Roles',
                    'users/delete_role' => 'Delete Roles',
                    )
            ),array('name' => 'Chapter Financials Budget',
            	'controller' => 'controller_budget',
                  'subs' => array(
                        'budget' => 'Budget Managers',
                        'budget/create' => 'Create Budget',
                        'budget/edit' => 'Edut Budget'
                  )
            ),array('name' => 'Chapter Financials Projects',
                  'controller' => 'controller_projects',
                	'subs' => array(
                        'projects/general_fund' => 'General Fund Projects',
                        'projects/grant_actuals' => 'Grant Actuals',
                        'projects/new_budget' => 'Create New Budget',
                        'projects/view' => 'Edit Budget',
                        'projects/delete' => 'Delete Budget',
                  )
            ),array('name' => 'Chapter Procurement',
            	'controller' => 'controller_procurement',
            	'subs' => array(
            		'procurement' => 'View Current Orders',
                    'procurement/all_orders' => 'View All Orders',
            		'procurement/my_orders' => 'View My Orders',
            		'procurement/templates' => 'View Template List',
            		'procurement/new_template' => 'Add Template',
            		'procurement/edit' => 'Edit Template',
            		'procurement/create' => 'Create Order',
            		'procurement/order' => 'Edit Order',
            		'procurement/delete' => 'Delete Order',
            	)
            ),array('name' => 'Timesheet',
            	'controller' => 'controller_timesheet',
            	'subs' => array(
            		'timesheet' => 'Timesheets List',
            		'timesheet/new_timesheet' => 'New Timesheet',
                    'timesheet/edit' => 'Edit Timesheet',
            		'timesheet_edit_all' => 'Edit Any Timesheet',
            		'timesheet/my_timesheets' => 'My Timesheets List',
            		'timesheet/template_list' => 'Templates List',
            		'timesheet/new_template' => 'New Template',
            		'timesheet/edit_template' => 'Edit Template',
                    'timesheet/delete' => 'Delete Timesheet',
                    'timesheet_delete_all' => 'Delete Any Timesheet',
            		'timesheet/delete_template' => 'Delete Template',
                    'approve_timesheet' => 'Approve Timesheet',
                    'new_from_tempalte' => 'Create Timesheet from Template',
                    'set_timesheet_pay_period' => 'Change Pay Period Date',
                    'set_timesheet_manager' => 'Set the Manager',
                    'timesheet/emails' => 'Manage Emails'
            	)
            ),array('name' => 'Time Off',
            	'controller' => 'controller_timeoff',
            	'subs' => array(
            		'timeoff' => 'Time Off Requests List',
            		'timeoff/my_timeoff_requests' => 'My Requests List',
            		'timeoff/new_timeoff_request' => 'Request Time Off',
            		'timeoff/edit' => 'Edit Request',
            		'timeoff/delete' => 'Delete Request',
                    'timeoff/emails' => 'Manage Emails'
            	)
            ),array('name' => 'Travel Reimbursement',
            	'controller' => 'controller_travel',
            	'subs' => array(
            		'travel' => 'Recent Reimbursement',
            		'travel/my_travel_requests' => 'My Travel Reimbursements',
            		'travel/new_travel_request' => 'New Reimbursement Request',
            		'travel/edit' => 'Edit Reimbursement Request',
            		'travel/delete' => 'Delete Reimbursement Request',
                    'approve_travel' => 'Approve Travel Expense',
                    'travel/emails' => 'Manage Emails'
            	)
            ),array('name' => 'Labor Accounts',
            	'controller' => 'controller_labor',
            	'subs' => array(
            		'labor' => 'Accounts',
            		'labor/new_account' => 'New Account',
            		'labor/edit_account' => 'Edit Account'
            	)
            ),
            // array('name' => 'Helpline',
            // 	'controller' => 'controller_helpline',
            // 	'subs' => array(
            // 		'helpline' => 'Intakes',
            // 		'helpline/new_profile' => 'New Log',
            // 		'helpline/profile' => 'Edit Log'
            // 	)
            // ),
            array('name' => 'Volunteers',
            	'controller' => 'controller_volunteers',
            	'subs' => array(
            		'volunteers' => 'List',
            		'volunteers/add' => 'New',
            		'volunteers/edit' => 'Edit',
            		'volunteers/delete' => 'Delete'
            	)
            ),array('name' => 'Grants',
            	'controller' => 'controller_grants',
            	'subs' => array(
            		'grants' => 'List',
            		'grants/add' => 'New',
            		'grants/edit' => 'Edit',
            		'grants/delete' => 'Delete',
                    'manage_funding_history' => 'Manage Funding History'
            	)
            ),
            // array('name' => 'LasrMetrics',
            // 	'controller' => 'controller_lasrmetrics',
            // 	'subs' => array(
            // 		'lasrmetrics/safe_return' => 'Safe Return',
            // 		'lasrmetrics/safe_return/new' => 'Add Safe Return',
            // 		'lasrmetrics/safe_return/edit' => 'Edit Safe Return',
            // 		'lasrmetrics/safe_return/delete' => 'Delete Safe Return',
            // 		'lasrmetrics/support_group' => 'Support Group',
            // 		'lasrmetrics/support_group/new' => 'Add Support Group',
            // 		'lasrmetrics/support_group/edit' => 'Edit Support Group',
            // 		'lasrmetrics/support_group/delete' => 'Delete Support Group',
            // 		'lasrmetrics/education_program' => 'Education Program',
            // 		'lasrmetrics/education_program/new' => 'Add Education Program',
            // 		'lasrmetrics/education_program/edit' => 'Edit Education Program',
            // 		'lasrmetrics/education_program/delete' => 'Delete Education Program',
            // 		'lasrmetrics/outreach' => 'Outreach',
            // 		'lasrmetrics/outreach/new' => 'Add Outreach',
            // 		'lasrmetrics/outreach/edit' => 'Edit Outreach',
            // 		'lasrmetrics/outreach/delete' => 'Delete Outreach',
            // 		'lasrmetrics/care_consultation' => 'Care Consultation',
            // 		'lasrmetrics/care_consultation/new' => 'Add Care Consultation',
            // 		'lasrmetrics/care_consultation/edit' => 'Edit Care Consultation',
            // 		'lasrmetrics/care_consultation/delete' => 'Delete Care Consultation',
            // 		'lasrmetrics/online_education' => 'Online Education',
            // 		'lasrmetrics/online_education/new' => 'Add Online Education',
            // 		'lasrmetrics/online_education/edit' => 'Edit Online Education',
            // 		'lasrmetrics/online_education/delete' => 'Delete Online Education',
            // 		'lasrmetrics/engagement_program' => 'Engagement Program',
            // 		'lasrmetrics/engagement_program/new' => 'Add Engagement Program',
            // 		'lasrmetrics/engagement_program/edit' => 'Edit Engagement Program',
            // 		'lasrmetrics/engagement_program/delete' => 'Delete Engagement Program',
            // 		'lasrmetrics/statistics' => 'Statistics',
            // 		'lasrmetrics/statistics/new' => 'Add Statistics',
            // 		'lasrmetrics/statistics/edit' => 'Edit Statistics',
            // 		'lasrmetrics/statistics/delete' => 'Delete Statistics'
            // 	)
            // ),
            array('name' => 'Resource Calendar',
                'controller' => 'controller_calendar',
                'subs' => array(
                    'calendar' => 'View Full Calendar',
                    'calendar/reserve' => 'Reserve Resource',
                    'calendar/edit' => 'Edit Resource',
                    'cal_edit_all' => 'Edit Others Reservations',
                    'calendar/my_reservations' => 'View My Reservations',
                    'calendar/delete' => 'Delete Reservations'
                )
            ),
            array('name' => 'Section Specific',
                'controller' => 'controller_specific',
                'subs' => array(
                    'change_status' => 'Change Form Status',
                    'view_salary_calculations' => 'View Salary Calculations'
                )
            )
        );

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -  
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in 
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	public function index()
	{  
		if($this->input->post('bulk_action') && ($this->input->post('bulk_action') != 'bulk')) {
			$this->users_model->do_bulk_action($this->input->post('bulk_action'), $this->input->post('b_action'));
		}

		$data['users'] = $this->users_model->get_all_users();       
		$this->load->view('users/list', $data);
	}

	public function add()
	{
		$this->form_validation->set_rules('user_name', 'Username', 'required|xss_clean|trim|is_unique[users.user_name]');
		$this->form_validation->set_rules('user_password', 'Password', 'required|xss_clean|matches[con_password]|trim');
		$this->form_validation->set_rules('con_password', 'Password Confirmation', 'required|xss_clean|matches[user_password]|trim');
		$this->form_validation->set_rules('user_email', 'Email', 'required|xss_clean|valid_email|trim|is_unique[users.user_email]');

		$this->form_validation->set_message('is_unique', '%s already exists in the database');

		if ($this->form_validation->run() == FALSE)
		{
			$accounts = $this->labor_model->get_accounts();

			foreach($accounts['rows'] as $account) {
				$data['accounts'][$account->ID] = $account->ledger;
			}

			$users = $this->users_model->get_all_users();

			foreach($users as $user) {
				$data['users'][$user->ID] = $user->user_name;
			}

			$data['user_roles'] = $this->users_model->getUserRoles();

			$this->load->view('users/add', $data);
		} 
		else 
		{
			$insert_id = $this->users_model->insert($this->input->post());
            $this->session->set_flashdata('user', 'User account has been saved.');
			redirect('users/edit/'.$insert_id);
		}
	}

	public function edit($id)
	{
		if($this->input->post('update_user'))
		{
			$this->users_model->update_user($this->input->post(), $id);
            $this->session->set_flashdata('user', 'User account has been updated.');
			redirect('users/edit/'.$id);
		}

		$data['user'] = $this->users_model->get_user($id);
		$accounts = $this->labor_model->get_accounts();

		foreach($accounts['rows'] as $account) {
			$data['accounts'][$account->ID] = $account->ledger;
		}

		$users = $this->users_model->get_all_users();
		$data['user_roles'] = $this->users_model->getUserRoles();

		foreach($users as $user) {
			$data['users'][$user->ID] = $user->user_name;
		}

		$this->load->view('users/edit', $data);
	}

	public function delete($id)
	{
		$this->db->where('ID', $id);
		$this->db->delete('users');

        $this->session->set_flashdata('user', "The user account(s) have been deleted.");

		redirect('users');
	}

	public function manage_roles()
	{
		$data['roles'] = $this->users_model->getUserRoles();

		$this->load->view('users/roles/list', $data);
	}

	public function add_role()
	{
		if ($this->input->post('save_role')) 
		{
			$id = $this->users_model->saveRole($this->input->post());
			$this->session->set_flashdata('updated', true);
            $this->session->set_flashdata('user', "The user role has been created successfully.");
			redirect('users/edit_role/'.$id);
		}

		$data = array();
		$data['cap_list'] = $this->cap_list;

		$this->load->view('users/roles/add', $data);
	}

	public function edit_role($id='')
	{
		if ($this->input->post('save_role')) 
		{
			$this->users_model->updateRole($id, $this->input->post());
			$this->session->set_flashdata('updated', true);
            $this->session->set_flashdata('user', "The user role has been updated.");
			redirect('users/edit_role/'.$id);
		}

		$role = $this->users_model->getUserRole($id);
		$data = array();
		$data['id'] = $role->ID;
        $data['name'] = $role->name;
		$data['description'] = $role->description;
		$data['caps'] = maybe_unserialize($role->caps);
		$data['cap_list'] = $this->cap_list;

		if(!is_array($data['caps']))
		{
			$data['caps'] = array();
		}

		$this->load->view('users/roles/edit', $data);
	}

	public function delete_role($id='')
	{
		$this->users_model->deleteRole($id);
        $this->session->set_flashdata('user', "The user role has been deleted.");
		redirect('users/manage_roles');
	}
}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */